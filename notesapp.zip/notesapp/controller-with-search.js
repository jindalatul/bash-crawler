window.addEventListener("load",init);
window.noteCounter=0;
function init(){
	
	document.getElementById("add-notes-option").addEventListener("click",showAddNotesDialog);
	
	document.getElementById("cancel-button").addEventListener("click",function(){
			document.getElementById("form-box").style.display="none";
	});

	document.getElementById("delete-all-option").addEventListener("click",deleteAllNotes);
	document.getElementById("delete-button").addEventListener("click",deleteNote)

		
	///
    document.getElementById("save-button").addEventListener("click",saveAction);
	
    document.getElementById("taskName").addEventListener("keyup",checkEmpty);   
    document.getElementById("search-box").addEventListener("keyup",search);     
}

function showAddNotesDialog()
{
		document.getElementById("form-box").children[0].children[0].innerHTML = "Add New Note";
		document.getElementById("taskName").value = "";
		document.getElementById("color").value= "default";
		document.getElementById("nid").value=0;
		document.getElementById("delete-button").style.display="none";
		document.getElementById("form-box").style.display="block";
}


function ShowEditNotesDialog()
{
	document.getElementById("form-box").children[0].children[0].innerHTML = "Updates Note";
	document.getElementById("taskName").value = this.innerHTML;
	document.getElementById("color").value= this.style.color;
	document.getElementById("nid").value=this.getAttribute("nid");
	document.getElementById("delete-button").style.display="block";
	document.getElementById("form-box").style.display="block";
}

function search()
{
	var results = noteOperation.searchResults(this.value);
	//alert(results.length);
	printNotes(results);
}

function checkEmpty(){
    var taskName = document.getElementById(this.id).value;
    if(taskName){
        document.getElementById("taskNameError").innerHTML="";
    }
}

function deleteNote()
{
	var nid = document.getElementById("nid").value;
	noteOperation.deleteNote(nid);
	printNotes(noteOperation.noteList);	
	document.getElementById("form-box").style.display="none";
}

function deleteAllNotes()
{
	noteOperation.emptyNotes();
	//// Delete all notes-option
	document.getElementById("notes-section").children[0].innerHTML="";
}

function saveAction()
{
		var taskName = document.getElementById("taskName").value;
		var color = document.getElementById("color").value;
		var nid = document.getElementById("nid").value;
        	
		if(!taskName){
            document.getElementById("taskNameError").innerHTML="TaskName Can't Be Empty";
            return ;
        }
		
        // Call Model
        if(nid>0)
				noteOperation.updateNotes(nid,taskName,color);
        else
				noteOperation.addNotes(taskName,color);
		
		printNotes(noteOperation.noteList);

		document.getElementById("form-box").style.display="none";
}

function printNotes(notes)
{
	  var ul = document.getElementById("notes-section").children[0];
	  //var notes = noteOperation.noteList;
	  
	  ul.innerHTML="";
	  
	  notes.forEach(function(currentNote){
	   var li = document.createElement("li");

		li.setAttribute("nid",currentNote.nid);
		li.style.color = currentNote.color;
		li.addEventListener("dblclick",ShowEditNotesDialog);
	    li.innerHTML = currentNote.name;
        ul.appendChild(li);
	  });
	  	
}
window.addEventListener("load",init);
function init(){
	
	document.getElementById("add-notes-option").addEventListener("click",showDialog);
	
	document.getElementById("cancel-button").addEventListener("click",function(){
			document.getElementById("form-box").style.display="none";
	});

	document.getElementById("delete-all-option").addEventListener("click",deleteAllNotes);

		
	///
    document.getElementById("save-button").addEventListener("click",addNotes);
	
    document.getElementById("taskName").addEventListener("keyup",checkEmpty);   
   
}

function showDialog()
{
	var edit_flag = document.getElementById("is-edit-flag").value;
	if(edit_flag ==1)
	{
		document.getElementsByTagName("div")[1].children[0].children[0].innerHTML = "Update Notes";
	}
	else
	{
		document.getElementsByTagName("div")[1].children[0].children[0].innerHTML = "Add New Note";
	}
	
	document.getElementById("form-box").style.display="block";

}

////save set flag to 0;

function editNotes()
{
	
	alert("dblclick");
	document.getElementById("taskName").value = this.innerHTML;
	document.getElementById("color").value= this.style.color;
	document.getElementById("is-edit-flag").value=1;
	showDialog();
}

function deleteNotes()
{
	
}

function deleteAllNotes()
{
		if(document.getElementsByTagName("div")[2].children[0].children.length<=0)
		{
			alert("No Notes are added");
			return false;
		}
		//// Delete all notes-option
		 document.getElementsByTagName("div")[2].children[0].innerHTML="";
}

function checkEmpty(){
    var taskName = document.getElementById(this.id).value;
    if(taskName){
        document.getElementById("taskNameError").innerHTML="";
    }
}
function addNotes(){
		alert(3);
		var taskName = document.getElementById("taskName");
		var color = document.getElementById("color");
        
		if(!taskName.value){
            document.getElementById("taskNameError").innerHTML="TaskName Can't Be Empty";
            return ;
        }
		
        // Call Model
        
		//taskOperation.addNotes(taskName,color);
		
        var ul = document.getElementsByTagName("div")[2].children[0];
        var li = document.createElement("li");
		
		li.addEventListener("dblclick",editNotes);
		
	    li.innerHTML = taskName.value;
		if(color.value=="default")
			li.style.color="#00000";
		else 
			li.style.color=color.value;

		taskName.value="";
		color.value="default";
		
        ul.appendChild(li);
		
}
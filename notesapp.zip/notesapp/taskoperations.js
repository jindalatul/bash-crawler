var taskOperation = {
    taskList:[],
    addTask:function(name,color){
        var task = new Task(name,color);
        this.taskList.push(task);
    }
}
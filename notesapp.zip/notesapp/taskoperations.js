function Note(name, color){
    this.name = name;
    this.color = color;
}

var noteOperation = {
    noteList:[],
    addNotes:function(name,color){
        var note = new Note(name,color);
        this.noteList.push(note);
    }
}

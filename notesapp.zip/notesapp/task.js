/*
function Notes(name, desc){
    this.name = name;
    this.color = color;
}

var taskOperation = {
    taskList:[],
    addTask:function(name,color){
        var task = new Task(name,color);
        this.taskList.push(task);
    }
	deleteTask:function(id){
		alert("Delete"+id);
    }
	editTask:function(id){
		alert("Edit"+id);
    }
}
*/